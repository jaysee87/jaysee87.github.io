function has(item)
  return Tracker:ProviderCountForCode(item) == 1
end

-- ALL CHECKS MARKED AS "HARD" IN THE RANDOMIZER ARE NOT USED HERE

-- WEIRD LOGIC CHECKS

-- Although bombs can be found in chests, the logic dictates that bombs are not considered unless you can buy them
-- Rupee chests are impossible to add here and a bomb toggle in the tracker is impractical, so for our purpose this will check if the player can get rupees
function get_bombs()
	return has("sword1") or
	has("sword2") or 
	has("shovel") or 
	(use_seeds() and has("emberseeds")) or
	(use_seeds() and has("scentseeds")) or	
	has("foolsore")
end

-- INTERACT RULES

function shoot_seeds()
	return has("slingshot1") or
	has("hss")
end


function use_seeds()
	return has("satchel") or
	shoot_seeds()
end

function destroy_bush()
	return has("sword1") or
	has("sword2") or 
	has("magicboomerang") or
	(use_seeds() and has("emberseeds")) or
	(shoot_seeds() and has("galeseeds")) or
	has("bracelet")
end

function destroy_pot()
	return has("sword2") or 
	has("bracelet")
end 

function destroy_mushroom()
	return has("magicboomerang") or 
	has("bracelet")
end 

function destroy_flower()
	return has("sword1") or 
	has("sword2") or 
	has("magicboomerang") or
	(use_seeds() and has("emberseeds")) or
	(shoot_seeds() and has("galeseeds"))
end 

function destroy_crystal()
	return has("sword1") or 
	has("sword2") or 
	has("bracelet")
end 

function hit_lever()
	return has("sword1") or 
	has("sword2") or
	has("rod") or
	has("foolsore") or
	has("boomerang") or
	has("magicboomerang") or
	shoot_seeds() or
	(has("emberseeds") and use_seeds()) or
	(has("scentseeds") and use_seeds())
end 

function hit_far_switch()
	return has("sword2") or 
	has("boomerang") or
	has("magicboomerang") or
	get_bombs() or
	shoot_seeds()
end 

function max_jump()
	local j = 0
	
	if (has("cape") and has("satchel") and has("pegasusseeds")) then
		j = 4
	elseif has("cape") then
		j = 3
	elseif (has("feather") and has("satchel") and has("pegasusseeds")) then
		j = 2
	elseif has ("feather") then
		j = 1
	end
	
	return j
end 

-- KILL RULES (order of appearance)

-- Generic damage check
function kill_normal()
	return has("sword1") or 
	has("sword2") or
	(use_seeds() and has("emberseeds")) or
	(use_seeds() and has("scentseeds")) or
	(use_seeds() and has("galeseeds")) or
	(use_seeds() and has("mysteryseeds")) or
	has("foolsore")
end

function kill_stalfos()
	return kill_normal() or 
	has("rod")
end

function kill_goriyabros()
	return has("sword1") or 
	has("sword2") or
	get_bombs() or
	has("foolsore")
end

function kill_goriya()
	return kill_normal()
end

function kill_aquamentus()
	return has("sword1") or 
	has("sword2") or
	(use_seeds() and has("scentseeds")) or
	get_bombs() or
	has("foolsore")
end

function kill_rope()
	return kill_normal()
end

function kill_hardhat_pit()
	return (use_seeds() and has("galeseeds")) or
	has("sword1") or 
	has("sword2") or
	has("boomerang") or
	has("magicboomerang") or
	(has("satchel") and has("scentseeds")) or
	has("foolsore")
end

function kill_moblin_pit()
	return has("sword1") or 
	has("sword2") or
	(use_seeds() and has("scentseeds")) or
	(shoot_seeds() and has("emberseeds")) or
	(shoot_seeds() and has("galeseeds")) or
	(shoot_seeds() and has("mysteryseeds")) or
	get_bombs() or
	has("foolsore") or
	(max_jump() >= 1 and kill_normal())
end

function kill_zol()
	return has("sword1") or 
	has("sword2") or
	(use_seeds() and has("emberseeds")) or
	(shoot_seeds() and has("galeseeds")) or
	(shoot_seeds() and has("mysteryseeds")) or
	get_bombs() or
	has("foolsore")
end

function kill_facade()
	return get_bombs()
end

function flip_beetle()
	return has("shield1") or
	has("shield2") or
	has("shovel")
end

function kill_beetle()
	return flip_beetle() and
	(has("sword1") or 
	has("sword2") or
	(use_seeds() and has("emberseeds")) or
	(use_seeds() and has("scentseeds")) or
	(use_seeds() and has("galeseeds")) or
	(use_seeds() and has("mysteryseeds")) or
	has("bracelet") or
	has("foolsore")) or
	(use_seeds() and has("galeseeds"))
end

function kill_mimic()
	return kill_normal()
end

function kill_omuai()
	return has("bracelet") and
	(has("sword1") or 
	has("sword2") or
	get_bombs() or
	(use_seeds() and has("scentseeds")) or
	has("foolsore"))
end

function kill_mothula()
	return max_jump() >= 1 and
	(has("sword1") or 
	has("sword2") or
	get_bombs() or
	(use_seeds() and has("scentseeds")) or
	has("foolsore"))
end

function kill_shroudedstalfos()
	return kill_stalfos() or
	has("bracelet")
end

function kill_likelike()
	return kill_normal() or
	has("bracelet") or
	has("rod")
end

function kill_watertektite()
	return kill_normal() or
	has("bracelet")
end

function kill_agunima()
	return use_seeds() and has("emberseeds") and
	(has("sword1") or 
	has("sword2") or
	get_bombs() or
	(use_seeds() and has("scentseeds")) or
	has("foolsore"))
end

function kill_wizzrobe_cart()
	return kill_normal() or 
	has("shield1") or
	has("shield2") or
	has("rod") or
	has("bracelet")
end

function kill_gohma()
	return (shoot_seeds() and has("emberseeds")) or
	(shoot_seeds() and has("scentseeds"))
end

function kill_moldorm()
	return has("sword1") or
	has("sword2") or
	(use_seeds() and has("scentseeds"))
end

function kill_ironmask()
	return has("sword1") or
	has("sword2") or
	(use_seeds() and has("emberseeds")) or
	(use_seeds() and has("scentseeds")) or
	has("foolsore")
end

function kill_armos()
	return has("sword1") or
	has("sword2") or
	get_bombs() or
	has("magicboomerang") or
	(use_seeds() and has("scentseeds")) or
	has("foolsore")
end

function kill_darknut()
	return has("sword1") or
	has("sword2") or
	get_bombs() or
	(use_seeds() and has("scentseeds")) or
	has("foolsore")
end

function kill_darknut_pit()
	return kill_darknut() or
	has("shield1") or
	has("shield2") or
	has("rod")
end

function kill_syger()
	return has("sword1") or
	has("sword2") or
	get_bombs() or
	(use_seeds() and has("scentseeds")) or
	has("foolsore")
end

function kill_digdogger()
	return has("glove")
end

function kill_hardhat_magnet()
	return has("glove") or
	(use_seeds() and has("galeseeds"))
end

function kill_vire()
	return has("sword1") or
	has("sword2") or
	get_bombs() or
	has("foolsore")
end

function kill_manhandla()
	return has("magicboomerang") and
	(has("sword1") or
	has("sword2") or
	get_bombs() or
	shoot_seeds() or
	has("foolsore"))
end

function kill_wizzrobe()
	return kill_normal()
end

function kill_keese()
	return kill_normal() or
	has("boomerang") or
	has("magicboomerang")
end

function kill_magunesu()
	return has("sword1") or
	has("sword2") or
	has("foolsore")
end

function kill_poe()
	return has("sword1") or
	has("sword2") or
	(use_seeds() and has("scentseeds")) or
	(use_seeds() and has("emberseeds")) or
	get_bombs() or
	has("foolsore")
end

function kill_darknut_across()
	return (has("sword2") or
	(shoot_seeds() and has("scentseeds")) or
	has("glove")) or
	(has("cape") and
	kill_darknut_pit())
end

function kill_wizzrobe_pit()
	return has("sword1") or
	has("sword2") or 
	has("shield1") or
	has("shield2") or
	(use_seeds() and has("scentseeds")) or
	has("rod") or
	get_bombs() or
	has("foolsore")
end

function kill_stalfos_pit()
	return kill_normal() or 
	has("shield1") or
	has("shield2") or
	(use_seeds() and has("scentseeds")) or
	has("rod") or
	get_bombs() or
	has("foolsore")
end

function kill_gleeok()
	return has("sword1") or
	has("sword2") or
	get_bombs() or
	has("foolsore")
end

function kill_frypolar()
	return use_seeds() and has("mysteryseeds") and
	(has("bracelet") or
	(use_seeds() and has("emberseeds")))
end

function kill_polsvoice_pit()
	return has("sword1") or
	has("sword2") or
	has("boomerang") or
	has("magicboomerang") or
	has("rod") or
	(use_seeds() and has("scentseeds")) or
	(use_seeds() and has("galeseeds")) or
	get_bombs() or
	has("shield1") or
	has("shield2") or
	has("foolsore") or
	has("mooshflute") or
	has("rickyflute") or
	has("dimitriflute") 
end

function kill_medusahead()
	return has("sword1") or
	has("sword2") or
	has("foolsore")
end

function kill_floormaster()
	return kill_normal()
end

function kill_onox()
	return (has("sword1") or
	has("sword2")) and
	max_jump() >= 1
end
