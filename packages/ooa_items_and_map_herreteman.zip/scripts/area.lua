-- LYNNA CITY/VILLAGE

function lynna()
	return destroy_bush() or has("echoes")
end

function ambi_palace()
	return (destroy_bush() or has("echoes")) and
	(destroy_bush() and has("mermaidsuit")) or
	has("ages")
end
function ambi_palace_hard()
	return ambi_palace() or
	-- guard skip
	(has("satchel") and has("scentseeds") and has("pegasusseeds"))
end

function rescue_nayru()
	return ambi_palace() and use_seeds() and has("mysteryseeds") and
	has("hook1") and has("sword1")
end
function rescue_nayru_hard()
	return ambi_palace_hard() and use_seeds() and has("mysteryseeds") and
	has("hook1") and has("sword1")
end

function raft()
	return has("rope") and has("chart") and
	(destroy_bush() or has("echoes"))
end

function shore()
	return has("rickygloves") or has("mermaidsuit") or
	(destroy_bush() and has("feather")) or
	has("bracelet") or
	(has("currents") and (has("feather") or has("flippers") or raft()))
end

function pop_balloon()
	return has("sword1") or has("boomerang")
end

-- CRESCENT ISLAND
function crescent_present()
	return has("dimitri") or
	(lynna() and has("mermaidsuit")) or
	(raft() and (has("currents") or (has("shovel") and has("echoes"))))
end
		
function crescent_past()
	return raft() or
	(lynna() and has("mermaidsuit")) or
	(has("dimitri") and has("currents"))
end

-- SYMMETRY CITY
function nuun()
	return lynna() and
	(has("currents") or 
	(has("shooter") and has("emberseeds") and
	(has("bracelet") or has("flippers") or has("dimitri"))))
end

function patch_nut()
	return has("sword1") or
	(has("cane") and 
	((use_seeds() and has("scentseeds")) or
	has("shield1") or
	has("boomerang") or
	has("hook1")))
end
function patch_nut_hard()
	return patch_nut() or
	has("cane") or
	(use_seeds() and has("scentseeds")) or
	has("shield1") or
	has("boomerang") or
	has("hook1")
end

--ROLLING RIDGE
function west_ridge_present()
	return has("hook1") and has("currents") and --From start
	(has("feather") or has("ages"))
	--(has("currents") and has("bombflower") 
	--and has("hook1") and (has("feather") or has("ages"))) --From Past Lynna, redundant
end

function west_ridge_past()
	return (has("bombflower") and has("hook1") and --From start
	(has("feather") or has("ages"))) or
	(west_ridge_present() and (has("ages") or
	(has("bracelet") and has ("echoes"))))--From present ridge
end

-- Clean this check up someday
function D5keys()
	return (has("cane") or has("hook1")) and --key 1, dark chest
	(has("hook1") or (has("feather") and has("cane"))) and --key 2, Any%
	has("shooter") and --key 3, 3 statues
	(destroy_pot() and has("cane") and has("feather") and 
	(has("shooter") or has("boomerang"))) and --key 4, 2 statues
	has("cane") --key 5, before somaria chest
end
function D5keys_hard()
	return (has("cane") or has("hook1") or
	(kill_hard() or push_enemy())) and --key 1, dark chest
	(has("hook1") or (has("feather") and has("cane"))) and --key 2, Any%
	has("shooter") and --key 3, 3 statues
	(destroy_pot() and has("cane") and has("feather") and 
	(has("shooter") or has("boomerang") or (has("sword1") and has("feather")))) and --key 4, 2 statues
	has("cane") --key 5, before somaria chest
end

function ridge_base_past_east()
	return lynna() and (has("feather") or has("ages")) and has("mermaidsuit") --through the sea
end

function openD6wall()
	return has("cane") and has("bombs") and has("bracelet") and has("feather") and
	((has("shooter") and has("emberseeds")) or
	(use_seeds() and has("emberseeds") and 
	(kill_ranged() or has("feather") or
	(has("satchel") and has("scentseeds")))))
end
function openD6wall_hard()
	return has("cane") and has("bombs") and has("bracelet") and has("feather") and
	((has("shooter") and has("emberseeds")) or
	(use_seeds() and has("emberseeds") and 
	(kill_ranged_hard() or has("feather") or
	(has("satchel") and has("scentseeds")))))
end
		
function D6keys()
	return (has("fippers") or has("feather")) and
	(has("shooter") or has("boomerang") or max_jump() >= 2) and --cross pits room
	has("satchel") and has("scentseeds") and--key 1, ropes
	(has("shooter") or has("boomerang") or (max_jump() >= 2 and
	(has("sword1") or has("hook1") or 
	(use_seeds() and has ("emberseeds")) or
	(use_seeds() and has ("scentseeds")) or
	(use_seeds() and has ("mysteryseeds"))))) and-- get to present hands room
	has("bombs") and has("hook1") and has("feather") and--key 2, dice
	openD6wall() and--get to vire spinner
	has("feather") or has("hook1") --key 3, spinner
end
function D6keys_hard()
	return (has("fippers") or has("feather")) and
	(has("shooter") or has("boomerang") or max_jump() >= 2) and --cross pits room
	has("satchel") and has("scentseeds") and--key 1, ropes
	(has("shooter") or has("boomerang") or (max_jump() >= 2 and
	(has("sword1") or has("hook1") or has("bombs") or 
	(use_seeds() and has ("emberseeds")) or
	(use_seeds() and has ("scentseeds")) or
	(use_seeds() and has ("mysteryseeds"))))) and-- get to present hands room
	has("bombs") and has("hook1") and has("feather") and--key 2, dice
	openD6wall_hard() and--get to vire spinner
	has("hook1") --key 3, spinner
end

-- ZORA SEAS
function refillD7()
	return has("hook2") or
	(has("hook1") and has("cane"))
end

function floodD7()
	return refillD7() and has("hook2")
end