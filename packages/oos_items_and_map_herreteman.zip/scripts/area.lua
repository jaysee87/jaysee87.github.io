-- HORON VILLAGE

function member_shop()
	return has("memberscard")
end

-- NORTH HORON

function north_stump()
	return destroy_bush() or any_flute()
end

function enter_d1()
	return has("d1key") and north_stump()
	--(south_swamp() and (has("flippers") or has("dimitri"))) 
end


function wet_lake()
	return has("north_winter") or has("north_spring") or has("north_fall") or
	has("winter") or has("spring") or has("fall")
end

function d5_stump_d1()
	return (north_stump() and
	(max_jump() >= 1 or has("ricky") or has("moosh")) and
	(has("winter") or has("north_winter") or
	has("flippers") or (has("dimitri")) and has("bracelet")))
end

function d5_stump()
	return d5_stump_d1() 
end

function enter_d5()
	return d5_stump() and
	(destroy_mushroom() or has("dimitri")) and
	(has("fall") or has("north_fall"))
end

-- WESTERN COAST

function pirate_ship()
	return has("bell")
	and pirate_house()
end

function graveyard()
	return pirate_ship() and
	(max_jump() >= 2 or
	has("coast_summer") or
	(get_bombs() and max_jump() >= 1 and has("summer")))
end

-- SUBURBS + WOODS OF WINTER

function suburbs()
	return (use_seeds() and has("emberseeds")) or 
	suburbs_swamp() or
	suburbs_lake() or
	suburbs_temple() or
	suburbs_hns() or
	--suburbs_sunken() or NOT BLOCKED BY SPRING ANYMORE
	suburbs_natzu()
end



function suburbs_swamp()
--portal_swamp() doesn't work? TODO
	return has("bracelet") and --bracelet is needed no matter what
	--getting to the swamp portal 
	(((has("ricky") or has("moosh") or --having either of these animals leads to the pegasus tree
	((max_jump() >= 1 or has("plain_winter"))) and  --get to the plain stump
	(has("summer") or has("plain_summer") or max_jump() >= 3)) and --climb up to pegasus tree
	hit_lever() and --drain the way
	((use_seeds() and has("pegasusseeds")) or max_jump() >= 3) and --cross to floodgate keyhole
	has("d3key") and --drain the swamp
	(any_flute() or max_jump() >= 2)) or --get to the portal
	has("flippers") or has("dimitri")) and --no matter what, swimming makes the portal accessible
	--getting to the portal from subrosia
	(max_jump() >= 1 or has("ribbon"))--cross from beach to temple
end

function suburbs_lake()
	return portal_lake() and
	--getting to the portal from subrosia
	(max_jump() >= 3 or (max_jump() >= 1 and (has("magnet") or has("bracelet")))) --jump past furnace
end

function suburbs_temple()
	return has("bracelet") and
	max_jump() >= 3 and --need a long jump no matter what
	portal_remains()
end

function suburbs_hns()
	return destroy_bush() and 
	(max_jump() >= 4 or --can go through pirates with this
	(has("bracelet") and has("shovel") and --otherwise, through mountain portal
	has("flippers") and
	(max_jump() >= 2 or (max_jump() >= 1 and has("magnet")))))
end

function suburbs_sunken()
	return scent_tree() and
	--cross natzu
	((has("natzu_dimitri") and (has("dimitri") or has("flippers")) and max_jump() >= 1) or --cross dimitri's natzu
	(has("natzu_moosh") and (has("moosh") or (remove_bush() and max_jump() >= 3))) or --crosh Moosh's natzu
	(has("natzu_ricky") and has("ricky"))) and --cross ricky's natzu
	--getting to the mountain portal
	has("flippers") and --dive to mountain
	(has("summer") or has("sunken_summer")) and --climb the vines
	(max_jump() >= 2 or (max_jump() >= 1 and has("magnet")))--cross shortcut to beach
end

function suburbs_natzu()
	return north_stump() and has("bracelet") and
	--cross natzu
	((has("natzu_dimitri") and (has("dimitri") or has("flippers")) and max_jump() >= 1) or --cross dimitri's natzu
	(has("natzu_moosh") and (has("moosh") or (remove_bush() and max_jump() >= 3))) or --crosh Moosh's natzu
	(has("natzu_ricky") and has("ricky"))) and --cross ricky's natzu
	--getting past spring stuff and cross water
	--(has("spring") or has("suburbs_spring")) and --get past spring blocks
	(max_jump() >= 1 or has("flippers") or has("winter") or has("suburbs_winter") or has("dimitri"))--cross the water to the south
end

function fairy_fountain()
	return suburbs() and
	(has("suburbs_winter") or has("winter") or 
	cross_water() or has("dimitri") or has("ricky"))
end

function mystery_tree()
	return fairy_fountain() and
	(((has("suburbs_winter") or has("winter")) and
	(has("shovel") or (max_jump() >= 1 and has("bracelet")) or any_flute())) or
	(has("suburbs_spring") or has("spring")) or
	(has("suburbs_summer") or has("summer")) or
	(has("suburbs_fall") or has("fall")))
end

function d2_A()
	return mystery_tree() and
	(destroy_bush() or any_flute())
end

function d2_B()
	return (mystery_tree() and
	has("bracelet") and
	(has("wow_summer") or has("ricky")))
	or (d2_bladekey() and has("bracelet"))
end

function d2_bladekey()
	return (mystery_tree() and
	has("bracelet") and
	(has("wow_summer") or has("ricky"))) or
	(d2_A() and use_seeds() and has("emberseeds") and kill_rope() and kill_goriya())
end

function enter_d2()
	return d2_A() or d2_B()
end

-- HOLODRUM PLAIN

function scent_tree()
	return scent_normal() or
	scent_suburbs()
end

function scent_normal()
	return north_stump() and
	(has("bracelet") or has("flippers") or has("dimitri"))
end

function scent_suburbs()
	--only path that doesn't require any of the above items
	return suburbs() and
	(has("winter") or has("suburbs_winter") or max_jump() >= 1) and --get to the fairy fountain
	(has("spring") or has("suburbs_spring")) and--climb up to natzu area
	((has("natzu_ricky") and has("ricky")) or--cross natzu with dimitri or ricky
	(has("natzu_moosh") and (has("moosh") or (remove_bush() and max_jump() >= 3))))
end

function plain_stump()
	return plain_stump_scent() or
	plain_stump_north()
end

function plain_stump_scent()
	return scent_tree() and
	((max_jump() >= 1 or has("plain_winter") or has("ricky") or has("moosh")) or--get over holes
	((has("flippers") or has("dimitri")) and destroy_bush())) --swim around
end

function plain_stump_north()
	return north_stump() and
	(has("flippers") or has("dimitri")) and destroy_bush() --swim around
end



-- SPOOL SWAMP

function pegasus_tree()
	return plain_stump() and
	(has("plain_summer") or has("summer") or has("cape") or has("ricky") or has("moosh"))
end

function swamp_stump()
	return pegasus_tree() and
	(has("bracelet") or hit_lever()) and
	((use_seeds() and has("pegasusseeds")) or has("flippers") or has("cape")) and
	has("bracelet") and has("d3key")
end

function dry_swamp()
	return has("swamp_summer") or has("swamp_winter") or has("swamp_fall") or
	(swamp_stump() and (has("summer") or has("winter") or has("fall")))
end

function south_swamp()
	return south_swamp_stump() or
	south_swamp_water() or
	south_swamp_scent() or
	south_swamp_suburbs() or
	south_swamp_pirates()
end

function south_swamp_stump()
	return swamp_stump() and
	(has("flippers") or has("dimitri") or --go through the water
	(dry_swamp() and (max_jump() >= 2 or any_flute()))) --go through other flute spots
end

function south_swamp_water()
	return plain_stump() and destroy_bush() and
	(has("flippers") or has("dimitri"))
end

function south_swamp_scent()
	return plain_stump() and
	(has("flippers") or has("dimitri"))
end

function south_swamp_suburbs()
	return suburbs() and destroy_bush() and --get to rosa portal
	max_jump() >= 1 and has("bracelet") --get to the beach portal and lift rock
end

function south_swamp_pirates()
	return has("bracelet") and (has("magicboomerang") or max_jump() >= 4) and --get to pirate portal
	max_jump() >= 1 and --jump to hns area
	--get to beach area
	(max_jump() >= 4 or--from bridge
	(max_jump() >= 2 or (max_jump() >= 1 and has("magnet"))))--through shortcut
end

function enter_d3()
	return swamp_stump() and (has("summer") or has("swamp_summer"))
end

-- NATZU

function moblin_keep()
	return (has("flippers") or max_jump() >= 4) and
	((has("natzu_ricky") and sunken_city()) or
	(has("natzu_dimitri") and scent_tree() and has("dimitri")) or
	(has("natzu_moosh") and (sunken_city() and (has("moosh") or (destroy_bush() and max_jump() >= 2)))))
end
-- SUNKEN CITY

function sunken_city()
	return sunken_suburbs() or
	sunken_natzu() or
	sunken_mountain() or
	sunken_pirates() or
	sunken_rosa() or
	sunken_lake() or
	sunken_swamp() or
	sunken_temple()
end

function sunken_natzu()
	return scent_tree() and
	--cross natzu
	((has("natzu_dimitri") and (has("dimitri") or has("flippers")) and max_jump() >= 1) or --cross dimitri's natzu
	(has("natzu_moosh") and (has("moosh") or (remove_bush() and max_jump() >= 3))) or --crosh Moosh's natzu
	(has("natzu_ricky") and has("ricky"))) --cross ricky's natzu
end

function sunken_suburbs()
	return fairy_fountain() and
	(has("spring") or has("suburbs_spring")) --has to be spring
end

function sunken_mountain()
	return scent_tree() and
	(has("flippers") or max_jump() >= 4) and --get to goron cave
	has("bracelet") and has("shovel") and --get to cucco mountain
	(has("summer") or has("sunken_summer")) and --summer requirement of rando
	has("flippers")--go through tunnel
end

function sunken_pirates()
	return (has("magicboomerang") or max_jump() >= 4) and --get to pirate portal
	max_jump() >= 1 and--get to hns area
	(has("summer") or has("sunken_summer")) and --summer requirement of rando
	has("flippers")--go through tunnel
end

function sunken_rosa()
	return suburbs() and destroy_bush() and --get to rosa portal
	max_jump() >= 4 and --get to hns area
	(has("summer") or has("sunken_summer")) and --summer requirement of rando
	has("flippers")--go through tunnel
end

function sunken_lake()
	return north_stump() and max_jump() >= 4 and (has("winter") or has("north_winter")) and --get to lake portal without any flute
	(has("summer") or has("sunken_summer")) and --summer requirement of rando
	has("flippers") --go through tunnel
end

function sunken_swamp()
	return south_swamp() and has("bracelet") and --get to swamp portal
	max_jump() >= 4 and --get to hns area
	(has("summer") or has("sunken_summer")) and --summer requirement of rando
	has("flippers") --go through tunnel
end

function sunken_temple()
	return scent_tree() and max_jump() >= 4 and --get to temple remains
	--getting to the temple portal
	((has("fall") and has("winter")) or--general check no matter the season
	(has("temple_winter") and has("shovel")) or --what to do in winter
	(has("temple_spring") and destroy_flower() and has("winter")) or --what to do in spring
	(has("temple_summer") and has("winter")) or --what to do in summer
	(has("temple_fall") and has("winter"))) and --what to do in autumn
	
	(has("summer") or has("sunken_summer")) and --summer requirement of rando
	has("flippers") --go through tunnel
end

function gale_tree()
	return sunken_city() and
	(has("flippers") or max_jump() >= 1 or has("sunken_winter"))
end

function dimitri_rescue()
	return gale_tree() and get_bombs()
end

-- MOUNT CUCCO

function mount_cucco()
	return cucco_goron() or
	cucco_pirates() or
	cucco_summer() 
	
end

function cucco_summer()
	return sunken_city() and has("flippers") and (has("sunken_summer") or has("summer"))
end

function cucco_goron()
	return scent_tree() and
	(has("flippers") or max_jump() >= 4) and --get to goron cave
	has("bracelet") and has("shovel")
end

function cucco_pirates()
	return (has("magicboomerang") or max_jump() >= 4) and --get to pirate portal
	max_jump() >= 1
end


function grab_cucco()
	return mount_cucco() and has("bracelet")
end

function moosh_rescue()
	return mount_cucco() and has("banana")
end

function talon_cave()
	return mount_cucco() and 
	(has("sunken_spring") or has("spring"))
end

function enter_d4()
	return talon_cave() and has("winter") and
	max_jump() >= 1 and has("bracelet") and
	has("d4key") and has("summer")
end

-- GORON MOUNTAIN

function goron_mountain()
	return (mount_cucco() and has("shovel") and has("bracelet")) or
	(scent_tree() and has("flippers")) or
	(temple_remains() and max_jump() >= 2 and (has("flippers") or max_jump >= 4))
end

-- TARM RUINS

function tarm_ruins()
	return pegasus_tree() and
	has("squarejewel") and has("roundjewel") and has("pyramidjewel") and has("xjewel")
end

function tarm_tree()
	return tarm_ruins() and destroy_mushroom() and
	has("winter") and has("spring") and has("summer") and has("fall")
end

function enter_d6()
	return tarm_tree() and destroy_bush() and (has("shovel") or (use_seeds() and has("emberseeds")))
end

-- SAMASA DESERT

function desert()
	return suburbs() and 
	pirate_house() 
end

-- TEMPLE REMAINS

function temple_remains()
	return scent_tree() and max_jump() >= 2 
	--goron mountain way requires bracelet and jump so this is essentially the same as counting for both
end


-- SUBROSIA LOCATIONS

function temple()
	return portal_rosa() or --normal way
	(portal_swamp() and (has("ribbon") or max_jump() >= 1)) or --through beach
	((portal_mountain() or portal_village()) and --through hns
	(max_jump() >= 4 or 
	(has("bracelet") and 
	(max_jump() >= 2 or (max_jump() >= 1 and has("bracelet")))))) or 
	(portal_lake() and max_jump() >= 1 and --through furnace
	(has("bracelet") or has("magnet") or max_jump() >= 3)) or
	(portal_remains() and has("bracelet") and max_jump() >= 3) --through remains
	
end



function beach()
	return portal_swamp() or
	(temple() and max_jump() >= 1) --actually covers everything???
	
	-- or (hns() and max_jump() >= 2 and has("bracelet")) or 
	-- or (hns() and max_jump() >= 1 and has("bracelet") and has("gloves")) or 
	-- or (furnace() and max_jump() >= 1 and has("bracelet")) or 
	-- or (furnace() and max_jump() >= 3) or 
	-- or (furnace() and max_jump() >= 1 and has("gloves")) or 
end



function hns()
	return ((portal_mountain() or portal_village()) and max_jump() >= 1) -- normalway
	--(max_jump() >= 4 and --ways that require max jump
	--(temple() or --from temple->bridge->hns
	--(portal_remains() and has("bracelet")))) --from remains portal 
end



function pirate_house()
	return portal_village() or (hns() and max_jump() >= 1)
end


function furnace()
	return portal_lake() or
	(beach() and max_jump() >= 3) or
	(beach() and has("glove"))
end



function bridge()
	return (temple() and max_jump() >= 1) or
	(portal_remains() and has("bracelet") and max_jump() >= 3) or
	(hns() and max_jump() >= 4)
end





-- PORTALS

function portal_rosa()
	return (suburbs() and (destroy_bush() or any_flute()))
	-- or temple() 
end

function portal_swamp()
	return (south_swamp() and has("bracelet"))
	-- or beach() 
end

function portal_mountain()
	return max_jump() >= 1 and mount_cucco()
end

function portal_lake()
	return (north_stump() and
	((wet_lake() and (max_jump() >= 1 or has("ricky") or has("moosh")) and
	(has("flippers") or (has("dimitri") and has("bracelet")))) or
	(max_jump() >= 4 and (has("north_winter") or has("winter")))))
	-- or furnace() 
end

function portal_village()
	return has("magicboomerang") or
	max_jump() >= 4
	-- or (pirate_house() and hit_lever()) 
end

function portal_remains()
	return temple_remains() and
	((has("fall") and has("winter")) or--general check no matter the season
	(has("temple_winter") and has("shovel") and max_jump() >= 4) or --what to do in winter
	(has("temple_spring") and destroy_flower() and max_jump() >= 4 and has("winter")) or --what to do in spring
	(has("temple_summer") and max_jump() >= 4 and has("winter")) or --what to do in summer
	(has("temple_fall") and max_jump() >= 1 and has("winter"))) --what to do in autumn
end

function portal_d8()
	return portal_remains() and get_bombs() and
	(has("temple_summer") or has("summer")) and
	(max_jump() >= 4 or (max_jump() >= 2 and has("gloves")))
end

