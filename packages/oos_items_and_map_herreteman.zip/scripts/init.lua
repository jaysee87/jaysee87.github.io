-- Load scripts required by this pack
--ScriptHost:LoadScript("scripts/access.lua")
ScriptHost:LoadScript("scripts/access.lua")
ScriptHost:LoadScript("scripts/area.lua")

-- Lua files must end with a newline
